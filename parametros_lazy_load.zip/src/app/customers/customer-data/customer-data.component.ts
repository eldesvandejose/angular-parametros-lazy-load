import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'a02-customer-data',
  templateUrl: './customer-data.component.html',
  styleUrls: ['./customer-data.component.css']
})
export class CustomerDataComponent implements OnInit {

  identifier: any;

  constructor(private customer: ActivatedRoute) {}

  ngOnInit() {
    this.identifier = this.customer.snapshot.params['id'];
  }
}
