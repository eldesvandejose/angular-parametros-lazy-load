import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a02-storing-list',
  templateUrl: './storing-list.component.html',
  styleUrls: ['./storing-list.component.css']
})
export class StoringListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
