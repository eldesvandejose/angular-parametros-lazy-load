import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a02-to-customers',
  templateUrl: './to-customers.component.html',
  styleUrls: ['./to-customers.component.css']
})
export class ToCustomersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
